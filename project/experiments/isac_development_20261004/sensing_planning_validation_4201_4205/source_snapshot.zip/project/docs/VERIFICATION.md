# 本轮验证记录

> 此文档保留原代理模式的说明与历史结果。新增仿真量测、EKF、SA、纯／残差 RL 和随机训练的接口见 [闭环实验指南](CLOSED_LOOP_STUDY.md)。


本文涉及的命令均从仓库根目录执行，并按 Windows CMD 单行书写。以下环境与硬件信息是迁移时的历史验证记录，不是运行项目的固定要求。

## 2026-09-27 结构整理

- 仓库根目录的旧实现与 `2uav/` 已归档到 `legacy/`，旧源码没有逻辑修改。
- 归档后的 14 项 legacy 回归测试全部通过。
- `project/tests` 的 40 项测试全部通过，用时 4.813 秒。

当前环境：Python 3.12.14、NumPy 2.5.2、PyTorch 2.14.0+cu130、Matplotlib 3.11.1。
原迁移与性能诊断使用 CPU 构建；下方历史结果保留当时口径。
使用 D:/anaconda3/envs/uav/python.exe；本轮为该环境补装了 Matplotlib 及其依赖。

## GPU 版 PyTorch 切换

- uav 环境已通过官方 cu130 wheel 源安装 torch 2.14.0+cu130，替换原 CPU 构建。
- 显卡为 NVIDIA GeForce RTX 5090 D，驱动 596.49；PyTorch CUDA 运行时为 13.0，设备能力为 12.0，构建包含 sm_120。
- 实际 CUDA 矩阵乘法与反向传播通过，梯度有限；不是只检查 CUDA 可用标记。
- example_config.json 的 ppo.device 已改为 cuda；PPOConfig 类默认 cpu 保留，需要不带配置运行时可传 --device cuda。
- GPU 上完成 2 × 128 个联合环境步的短训练、保存、评估及绘图；运行日志明确显示 device=cuda:0。
- GPU checkpoint 重载后参数均在 CUDA，同一组种子的逐回合评估与保存记录完全一致。
- 新环境下 40 项项目测试全部通过。
- 结果及设备信息见 output/gpu_smoke/runtime_verification.json。短训练用于验证实现，不是策略性能结论。
- pip check 另检出 scipy-stubs 1.18.1.0 缺少 optype；它不属于 torch 依赖，本次未修改该独立类型提示依赖。

## 已完成

- project/tests 下 40 项 unittest 全通过，包含公式校验与独立目录运行测试。
- 原 `legacy/test_c_happo_hybrid_beamforming.py` 的 4 项回归测试全通过。
- 新增 Python 文件最长 186 行。
- 完成 2 epoch × 128 联合环境交互的短训练；策略和价值更新数值有限。
- policy.pt 可通过正式 evaluate 命令重新加载；相同评估种子下，逐回合指标和保存轨迹完全一致。
- 图表生成成功，已检查导航轨迹、评估指标及训练图的可读性。
- 子任务误放在 UAV 根目录的测试/许可证已移动至 project，对应临时目录与缓存已清理。

## 物理公式迁移验证

- 原 `legacy/test.py` 的 32 个物理/数值函数已迁入 project 内六个模块，文件为 52～139 行。
- 逐函数对照完成 174 个数值结果的零容差比较，以及 19 项非法输入的异常类型和消息比较，全部一致。
- 对照覆盖 1/2/3 架 UAV、通信直接感知干扰的两个分支、CI 默认/自定义权重，以及 PCRB 的两个信息矩阵输入分支。
- 永久公式测试使用独立的手算值及功率、协方差约束，不导入 `legacy/test.py`。
- 独立目录测试只复制 project 源码，并阻断旧模块导入；公式演示、8 步短训练、模型保存和评估全部通过。
- 使用迁移前保存的 PPO 模型及导航对照重新评估，逐回合统计和所有轨迹字段与原记录完全一致。
- `legacy/test.py` 未修改。运行新环境不再依赖历史代码。

函数映射、公式口径和独立运行方法见 [PHYSICS_MIGRATION.md](PHYSICS_MIGRATION.md)。
以下 256 步训练结果来自迁移前的短训练；本次模块拆分没有改变其评估结果。

## 单行命令、设备诊断与轨迹图更新

- CMD 中实际激活 uav 环境，用单行 python 命令完成短训练；--eval-seed 别名和新的采样/更新时间字段均正常。
- 本机训练设备为 CPU，PyTorch 为 2.14.0+cpu；运行时计算线程为 1，逻辑核数为 32。短测物理环境计算占采样时间的主要部分。
- 新评估轨迹保存基站位置、黑飞真值和估计值。40 项测试包括非零基站、旧轨迹兼容及 Actor/Critic 观测不直接读取真值的检查。
- 原 run_seed7 图表已重绘。相同 checkpoint 和种子重新评估至 output/run_seed7_visualized，所有原有轨迹字段及逐回合指标与旧结果完全一致。
- 已视觉检查新轨迹图：基站、两机、黑飞真实/估计轨迹清楚可辨。绘图视角已调整，避免黑飞轨迹投影成一点。
- 黑飞估计仍为加噪代理，本次没有新增感知测量滤波闭环，也没有将绘图真值接入策略观测。

## 结果的含义

| 策略 | 评估种子 | 团队成功 | 备注 |
| --- | --- | --- | --- |
| 无学习 GoalController | 101、102 | 2/2 | UAV 0 在 27 s 到达，UAV 1 在 20 s 到达；无碰撞、无越界请求 |
| 256 步短训练 PPO | 101、102 | 0/2 | 仅验证实现和保存链路，尚未学会到达，不能视为收敛或性能结论 |

短训练的价值损失约从 9439.8 降至 7343.3，但只有两个更新批次，不能据此判断学习效果。
PPO 评估仍频繁请求越界，说明需要正式训练和多种子实验；环境安全裁剪已记录这些请求。

可查看 `project/output/smoke`、`project/output/smoke_reload` 和 `project/output/baseline` 中的 CSV、JSON、NPZ、PNG。
物理模型局限、奖励口径、运行命令和修改入口见 [GUIDE.md](GUIDE.md)。

## 2026-09-27：基线对比实验

- 新增 Random、PD、APF、有限候选集中导航 MPC，与原 Goal 和冻结 MAPPO 统一评估。
- project/tests 共58项测试通过（4.656秒），涵盖MPC预测与实际环境一致、到达冻结、随机策略每回合复现、前缀统计与完整benchmark产物。
- 6种方法 × 5场景 × 100个连续评估种子（2001–2100），共3000回合完整完成；所有前缀指标均有100个有效样本。
- 300轮、614400联合环境步、训练seed7的已有MAPPO权重保持不变；未根据正式结果调整控制器。
- 已核对完整原始CSV、聚合统计、配对差、源码与模型哈希，以及结果图；实验快照保存在 [experiments/benchmark_20260927](../experiments/benchmark_20260927/REPORT.md)。
- 原场景100%到达并不代表超过简单方法；MAPPO在交叉航线和改变终点场景0/100成功，详见 [BASELINE_RESULTS.md](BASELINE_RESULTS.md)。
