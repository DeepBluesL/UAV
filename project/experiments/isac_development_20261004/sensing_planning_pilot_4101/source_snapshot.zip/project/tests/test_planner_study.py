import unittest

from project.planner_study import configurations, controller
from project.sensing_planning import SensingAwareMPCController, SensingAwareSAController


class TestPlannerStudy(unittest.TestCase):
    def test_grid_controller_settings_preserve_family_budgets(self):
        configs, _ = configurations(["nominal"])
        cfg = configs["nominal"]
        sa = controller("sa", {"family": "sa", "sensing_weight": 20,
                               "communication_weight": 0}, cfg, 1.)
        mpc = controller("mpc", {"family": "mpc", "sensing_weight": 2000,
                                 "communication_weight": 0}, cfg, 1.)
        self.assertIsInstance(sa, SensingAwareSAController)
        self.assertIsInstance(mpc, SensingAwareMPCController)
        self.assertEqual((sa.horizon, sa.iterations), (4, 16))
        self.assertEqual(mpc.horizon, 3)
        self.assertEqual(sa.communication_weight, 0.)
        self.assertEqual(mpc.uncertainty_ref, 1.)


if __name__ == "__main__":
    unittest.main()
